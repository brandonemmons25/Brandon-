<?php
/**
 * 03A — Neighborhood Directory. Sixteen at launch, so the full set renders at
 * once and search and sort run in the browser.
 *
 * @var WP_Post[] $posts
 * @var string    $featured
 * @var string    $count_label
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="ao-directory ao-directory--terms" data-ao-terms="neighborhoods"<?php echo AO_Shortcodes::style( $width, $columns ); ?>>

	<div class="ao-bar">
		<div class="ao-pill ao-pill--search">
			<label class="screen-reader-text" for="ao-nbhd-search">Search Neighborhoods</label>
			<input type="search" id="ao-nbhd-search" class="ao-term-search ao-search-input" placeholder="Search Neighborhoods">
		</div>
		<div class="ao-pill ao-pill--sort">
			<span class="ao-pill-label">Sort</span>
			<label class="screen-reader-text" for="ao-nbhd-sort">Sort by</label>
			<select id="ao-nbhd-sort" class="ao-term-sort ao-sort-select">
				<option value="asc">A–Z</option>
				<option value="desc">Z–A</option>
			</select>
		</div>
	</div>

	<?php
	// Hides while the directory is searched or sorted the other way.
	echo $featured; // phpcs:ignore WordPress.Security.EscapeOutput
	?>

	<div class="ao-meta">
		<?php if ( $count_label ) : ?>
			<span class="ao-count"><?php echo esc_html( count( $posts ) . ' ' . $count_label ); ?></span>
		<?php endif; ?>
	</div>

	<div class="ao-results ao-results--terms">
		<?php
		foreach ( $posts as $post ) {
			echo ao_template( 'card-neighborhood.php', array( 'post_id' => $post->ID, 'featured' => false ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		}
		?>
	</div>

	<p class="ao-empty" hidden>No neighborhoods match that search.</p>
</div>
