(function () {
    function init() {
        var qs = document.getElementById('quick-search');
        if (!qs) return;

        var sr = null;
        var els = qs.querySelectorAll('*');
        for (var i = 0; i < els.length; i++) {
            if (els[i].shadowRoot) { sr = els[i].shadowRoot; break; }
        }
        if (!sr) { setTimeout(init, 200); return; }

        var style = document.createElement('style');
        style.textContent = [
            '[class*="quick-search-price"] > [class*="MuiPaper"],',
            '[class*="quick-search-bed-bath"] > [class*="MuiPaper"],',
            '[class*="quick-search-property-type"] > [class*="MuiPaper"] {',
            '  position: fixed !important;',
            '  z-index: 2147483647 !important;',
            '}'
        ].join('\n');
        sr.appendChild(style);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () { setTimeout(init, 400); });
    } else {
        setTimeout(init, 400);
    }
})();
